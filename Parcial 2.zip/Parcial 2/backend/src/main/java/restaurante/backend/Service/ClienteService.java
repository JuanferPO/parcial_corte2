package restaurante.backend.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import restaurante.backend.Document.Cliente;
import restaurante.backend.IService.IClienteService;

import java.util.List;

@Service
public class ClienteService {
    @Autowired
    private IClienteService repository;
    @Override
    public List<Cliente> findAll(){
        return repository.findAll();
    }
}
